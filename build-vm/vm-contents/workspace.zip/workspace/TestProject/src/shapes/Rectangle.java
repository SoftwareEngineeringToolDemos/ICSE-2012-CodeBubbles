package shapes;

public class Rectangle implements Shape{

	int length;
	int breadth;
	
	public Rectangle(int l, int b) {
		length = l;
		breadth = b;
	}
	@Override
	public int getArea() {
		return length*breadth;
	}

}
