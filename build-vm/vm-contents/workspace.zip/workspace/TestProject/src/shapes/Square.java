package shapes;

public class Square implements Shape{
	
	int length;
	
	        public Square(int l) {
		length = l;
	}

	@Override
	public int getArea() {
		return length*length;
	}

}
