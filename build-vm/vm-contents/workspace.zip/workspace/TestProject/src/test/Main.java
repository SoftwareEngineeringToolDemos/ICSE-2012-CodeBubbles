/********************************************************************************/
/*                                                                              */
/*              Main.java                                                       */
/*                                                                              */
/*      Default implementation of main                                          */
/*                                                                              */
/********************************************************************************/



package test;

import shapes.Rectangle;
import shapes.Shape;
import shapes.Square;

public class Main
{


/********************************************************************************/
/*                                                                              */
/*      Main program                                                            */
/*                                                                              */
/********************************************************************************/

public static void main(String [] args)
{
   Shape square = new Square(10);
   
   Shape rectangle = new Rectangle(10,9);
   
   System.out.println("Area of the square is : "+square.getArea());
   
   System.out.println("Area of the rectangle is : "+rectangle.getArea());
   
}



}       // end of class Main




/* end of Main.java */
